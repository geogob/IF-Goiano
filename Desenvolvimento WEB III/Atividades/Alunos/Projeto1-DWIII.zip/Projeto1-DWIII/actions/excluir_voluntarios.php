<?php 
	    //Realizando a conexão com o banco
	    require '../Configuracoes/config.php'; 
	    require '../Configuracoes/conexao.php';
	    $link = DB_connect();
	    //Recebe 
	    $id= $_GET['id'];

	    $query = "SELECT * FROM voluntarios_has_atos WHERE voluntarios_id_voluntarios = '$id'";
	    $result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

	    if ($result) {
	    	$query = "DELETE FROM voluntarios_has_atos WHERE voluntarios_id_voluntarios = '$id'";
	    	$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));
	    	header("Location:../pages/voluntarios.php"); 
	    }

	    $query = "SELECT * FROM voluntarios_has_regiao WHERE voluntarios_id_voluntarios = '$id'";
	    $result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

	    if($result){
	    	$query = "DELETE FROM voluntarios_has_regiao WHERE voluntarios_id_voluntarios = '$id'";
	    	$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));
	    	header("Location:../pages/voluntarios.php"); 
	    }

		//Consulta SQL de inserção:
		$query = "DELETE FROM voluntarios WHERE id_voluntarios = '$id'"; 
		$result = mysqli_query($link, $query) or die(mysqli_connect_error($link));
		if($result){
			header("Location:../pages/voluntarios.php");
		}else{
			echo "Erro ao tentar excluir vonluntário";
		}
	    //Fecha Conexão	
	    DB_Close($link);
?>