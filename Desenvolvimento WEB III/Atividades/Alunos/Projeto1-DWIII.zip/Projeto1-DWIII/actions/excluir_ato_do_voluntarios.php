<?php 
	    //Realizando a conexão com o banco
	    require '../Configuracoes/config.php'; 
	    require '../Configuracoes/conexao.php';
	    $link = DB_connect();
	    
	    //Recebe 
	    $id_voluntario = $_GET['idv'];
	    $id_ato = $_GET['ida'];

		//Consulta SQL de inserção:
		$query = "DELETE FROM voluntarios_has_atos WHERE voluntarios_id_voluntarios = '$id_voluntario' AND atos_id_ato = '$id_ato'"; 
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/mais_dados_voluntario.php?id='.$id_voluntario.'">';
		}else{
			echo "Erro ao tentar excluir a região $regiao";
		}
?>