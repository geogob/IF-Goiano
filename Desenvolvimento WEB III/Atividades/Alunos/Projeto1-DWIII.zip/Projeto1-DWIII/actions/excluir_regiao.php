<?php 
	    //Realizando a conexão com o banco
	    require '../Configuracoes/config.php'; 
	    require '../Configuracoes/conexao.php';
	    $link = DB_connect();
	    
	    //Recebe 
	    $regiao= $_GET['regiao'];

	    $query = "SELECT * FROM voluntarios_has_regiao WHERE regiao_regiao = '$regiao'";
	    $result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

	    if($result){
	    	$query = "DELETE FROM voluntarios_has_regiao WHERE regiao_regiao = '$regiao'";
	    	$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));
	    	header("Location:../pages/regioes.php"); 
	    }

		//Consulta SQL de inserção:
		$query = "DELETE FROM regiao WHERE regiao = '$regiao'"; 
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			header("Location:../pages/regioes.php");
		}else{
			echo "Erro ao tentar excluir a região $regiao";
		}
	    //Fecha Conexão	
	    DB_Close($link);
?>