<?php 
	define('DB_HOSTNAME', 'localhost'); //Nome de HOST
	define('DB_USERNAME', 'root'); //Usuário
	define('DB_PASSWORD', 'ifgoiano'); //Senha
	define('DB_DATABASE', 'trabalho_volutario'); //Nome do BD
	//define('DB_PREFIX', 'dw3');
	define('DB_CHARSET', 'utf8');	
?>