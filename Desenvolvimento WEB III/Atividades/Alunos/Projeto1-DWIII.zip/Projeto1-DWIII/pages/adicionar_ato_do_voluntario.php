<!DOCTYPE html>
<html>
<head>
	<title>Voluntários</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php
		include 'bar.php';
	?>

	<div class="row esp_cima">
		<div class="container col-md-4 col-md-offset-4">
			<?php
			//Realizando a conexão com o banco
			require '../Configuracoes/config.php'; 
			require '../Configuracoes/conexao.php';
			$link = DB_connect();

			$id = $_GET['id'];

			$query = "SELECT nome FROM voluntarios WHERE id_voluntarios = '$id'";
			$result = @mysqli_query($link, $query);

			$registro = mysqli_fetch_assoc($result);

			$voluntario = $registro['nome'];

			echo'<h1 class="page-header">Adicionar ato para '.$voluntario.'</h1>';

			$query = "SELECT * FROM atos";
			$result = @mysqli_query($link, $query);

			if (isset($_POST['ato'])) {
					 
					//Recebe 
					$ato = $_POST['ato'];

					//Consulta SQL de inserção:
					$query = "INSERT INTO voluntarios_has_atos (voluntarios_id_voluntarios, atos_id_ato) VALUES ('$id', '$ato')";
					$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

					if($result){
						echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/mais_dados_voluntario.php?id='.$id.'">';
					}else{
						echo '<p class="erro">Erro ao cadastrar $nome</p>';
					}
					   //Fecha Conexão	
					   DB_Close($link);
				}

			?>

			

			<form class="form-group" method="POST">
				<select name="ato" class="form-control">
					<option value="null">-----------------</option>
					<?php

						while ($registro = mysqli_fetch_assoc($result)) {
							echo'<option value="'.$registro['id_ato'].'">'.$registro['ato'].'</option>';

						}


					?>
				</select>
				<input type="submit" value="Adicionar" class="btn btn-primary">
			</form>

		</div><!-- container -->
	</div>
</body>
</html>