<!DOCTYPE html>
<html>
<head>
	<title>Editar cachorro</title>
	<link rel="stylesheet" type="text/css" href="BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php

	include 'bar.php';
	//Realizando a conexão com o banco
	require '../Configuracoes/config.php'; 
	require '../Configuracoes/conexao.php';
	$link = DB_connect();

	$id = $_GET['id'];

	$query = "SELECT * FROM voluntarios WHERE id_voluntarios = '$id'";
	$result = @mysqli_query($link, $query);

	$registro = mysqli_fetch_assoc($result);

	$nome = $registro['nome'];
	$idade = $registro['idade'];
	$sexo = $registro['sexo'];

	if(isset($_POST['nome'])){

		$nomeed = $_POST['nome'];
		$idadeed = $_POST['idade'];
		$sexoed = $_POST['sexo'];
		$donoed = $_POST['dono'];

		$query = "UPDATE voluntarios SET nome = '$nomeed', idade = '$idadeed', sexo = '$sexoed' WHERE id_voluntarios = '$id'";
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/voluntarios.php">';

		}else{
			echo "Não foi possível editar! Tente novamente.";
		}

	}


	?>
	<div class="row esp_cima">

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/pages/voluntarios.php">Voluntários</a></li>
	  				<li class="breadcrumb-item active">Editar voluntário</li>
			</ol>

		</div>

		<div class="container col-md-4 col-md-offset-4">

					<h2 class="page-header">Cadastro de voluntário</h2>

					<!-- Criando formulário -->
					<div class="form-group">
						<form method="POST">
							<label for="nome">
								Nome:
							</label>
							<?php
								echo sprintf('<input type="text" name="nome" class="form-control" id="nome" placeholder="Digite o nome do voluntário" value="%s"', $nome);
							?>
							<label for="idade">
								idade:
							</label>
							<?php
								echo'<input type="number" name="idade" class="form-control" id="idade" placeholder="Digite a idade do voluntário" value=' . $idade . '>';
							?>
							<label>
								Sexo:
							</label>
							<div class="radio">

							<?php

								if($sexo == "Masculino"){
									echo'<label>
										<input type="radio" name="sexo" value="Masculino" checked>Masculino
									</label>
									<label>
										<input type="radio" name="sexo" value="Feminino" >Feminino
									</label>';

								}else if($sexo == "Feminino"){
									echo'<label>
										<input type="radio" name="sexo" value="Masculino" >Masculino
									</label>
									<label>
										<input type="radio" name="sexo" value="Feminino" checked>Feminino
									</label>';

								}else{
									echo'<label>
										<input type="radio" name="sexo" value="Masculino" >Masculino
									</label>
									<label>
										<input type="radio" name="sexo" value="Feminino">Feminino
									</label>';
								}

								
							?>
							</div><!-- radio -->

							<a href="http://localhost/Projeto1-DWIII/pages/voluntarios.php" class="btn btn-danger">Cancelar</a>
							<input type="submit" value="Editar" class="btn btn-primary">

						</form>

					</div><!-- form -->

		</div>
</div>
</body>
</html>