<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bar.css">
</head>
<body>
	<nav class="nav navbar-fixed-top">
		<div class="prin">
			<a href="http://localhost/Projeto1%20-%20DWIII/index.php"><h3 class="h3">Trabalho voluntários</h3></a>
				<center>
					<a href="voluntarios.php" class="link_barra">Voluntários</a>
					<a href="atos.php" class="link_barra">Atos voluntários</a>
					<a href="regioes.php" class="link_barra">Regiões</a>
				</center>
		</div>
	</nav>
</body>
</html>