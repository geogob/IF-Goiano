<!DOCTYPE html>
<html>
<head>
	<title>Regiões</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php
		include 'bar.php';
	?>

	<div class="row esp_cima"> 

		<div class="container col-md-8 col-md-offset-2 fixed">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item active">Regiões</li>
			</ol>

		</div>

		<div class="container col-md-6 col-md-offset-2">

			<?php 
			    //Realizando a conexão com o banco
			    require '../Configuracoes/config.php'; 
			    require '../Configuracoes/conexao.php';
			    $link = DB_connect();

				//Consulta SQL de inserção:
				$query = "SELECT * FROM regiao"; 
				$result = @mysqli_query($link, $query);
				echo '<table class="table table-striped table-bordered table-hover">';
				echo '<tr>';
				echo '<td> <h2> N° </h2> </td>';
				echo '<td> <h2> Região </h2> </td>';
				echo '<td> <h2> Quantidade de beneficiados </h2> </td>';
				echo '<td colspan="3"> <h2> Opções </h2> </td>';
				echo '</tr>';

				$num = 1;
				while ($registro = mysqli_fetch_assoc($result)) {
					echo '<tr>';
					echo '<td>'.$num.'</td>';
					echo '<td>'.$registro["regiao"].'</td>';
					echo '<td>'.$registro["quant_beneficiados"].'</td>';
					$regiao = $registro["regiao"];
					echo '<td> <a href="../actions/excluir_regiao.php?regiao='.$regiao.'"><span class="glyphicon glyphicon-trash"></span></a> </td>';
					echo '<td> <a href="../pages/editar_regiao.php?regiao='.$regiao.'"><span class="glyphicon glyphicon-pencil"></span></a>';
					echo '<td> <a href="../pages/mais_dados_regiao.php?regiao='.$regiao.'"><span class="glyphicon glyphicon-option-horizontal"></span></a> </td>';

					$num ++;
				}
				echo '</table>';

			?>
		</div>

		<div class="container col-md-3">
			<div class="fixed">
				<h1 class="page-header">Cadastro de regiões</h1>

					<!-- Criando formulário -->
					<div class="form-group form_fixed col-md-12">
						<form method="POST">
							<label for="regiao">
								Região:
							</label>
							<input type="text" name="regiao" id="regiao" class="form-control" placeholder="Digite a região que o voluntário atua"><br/>
							<label for="quant_benef">
								Quantidade de beneficiados:
							</label>
							<input type="text" name="quant_benef" id="quant_benef" class="form-control" placeholder="Digite a quantidade de beneficiados"><br/>

							<input type="submit" value="Cadastrar" class="btn btn-primary">
						</form>
					</div>
				</div>

			<?php
				if (isset($_POST['regiao'])) {

					   //Recebe 
					   $regiao = $_POST['regiao'];
					   $quant_benef = $_POST['quant_benef'];

					//Consulta SQL de inserção:
					$query = "INSERT INTO regiao (regiao, quant_beneficiados) VALUES ('$regiao', '$quant_benef')";
					$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

					if($result){
						echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/regioes.php">';
					}else{
						echo '<p class="">Erro ao cadastrar a regiao $regiao</p>';
					}
					   //Fecha Conexão	
					   DB_Close($link);
				}

			?>
		</div>
	</div><!-- row -->
</body>
</html>