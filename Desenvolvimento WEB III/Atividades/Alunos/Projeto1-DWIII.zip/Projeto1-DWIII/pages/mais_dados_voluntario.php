<!DOCTYPE html>
<html>
<head>
	<title>Voluntários</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php
		include 'bar.php';
	?>

	<div class="row esp_cima">

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/pages/voluntarios.php">Voluntários</a></li>
	  				<li class="breadcrumb-item active">Mais dados do voluntário</li>
			</ol>

		</div>

		<div class="container col-md-8 col-md-offset-2">
			<?php
			//Realizando a conexão com o banco
			require '../Configuracoes/config.php'; 
			require '../Configuracoes/conexao.php';
			$link = DB_connect();

			$id_voluntario = $_GET['id'];

			$query = "SELECT * FROM voluntarios WHERE id_voluntarios = '$id_voluntario'";
			$result = @mysqli_query($link, $query);

			$registro = mysqli_fetch_assoc($result);

			$voluntario = $registro['nome'];
			$idade = $registro['idade'];
			$sexo = $registro['sexo'];

			echo '<table class="table table-striped table-bordered table-hover">';
			echo '<tr>';
			echo '<td><h3>Nome: '.$voluntario.'</h3></td>';
			echo '<td> <h3 class="dados">Idade: '.$idade.'</h3> </td>';
			echo '<td> <h3 class="dados">Sexo: '.$sexo.'</h3> </td>';
			echo '</tr>';
			echo '</table>';
			?>
		</div>
	</div>

	<div class="row">
		<div class="container col-md-4 col-md-offset-2">

			<?php

			//Consulta SQL de inserção:
			$query = "SELECT a.id_ato, a.ato FROM atos a, voluntarios v, voluntarios_has_atos va WHERE a.id_ato = va.atos_id_ato AND v.id_voluntarios = va.voluntarios_id_voluntarios AND v.id_voluntarios = '$id_voluntario'"; 
			$result = @mysqli_query($link, $query);

			echo '<table class="table table-striped table-bordered table-hover">';
			echo '<tr>';
			echo '<td> <h2> N° </h2> </td>';
			echo '<td> <h2> Atos</h2> </td>';
			echo '<td> <h2> Opções </h2> </td>';
			echo '</tr>';

			$num1 = 1;
			while ($registro = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo '<td>'.$num1.'</td>';
				echo '<td> <i>'.$registro["ato"].'</i></td>';
				$id_ato = $registro["id_ato"];
				echo '<td > <a href="../actions/excluir_ato_do_voluntarios.php?idv='.$id_voluntario.'&ida='.$id_ato.'"><span class="glyphicon glyphicon-trash"></span></a>';
				echo '</tr>';

				$num1 ++;
			}
			echo '<td colspan ="3"><a href="adicionar_ato_do_voluntario.php?id='.$id_voluntario.'">adicionar ato para '.$voluntario.'</a></td>';
			echo '</table>';
		?>
		</div><!-- container -->
		<div class="container col-md-4">
			<?php

			$query = "SELECT nome FROM voluntarios WHERE id_voluntarios = '$id_voluntario'";
			$result = @mysqli_query($link, $query);

			$registro = mysqli_fetch_assoc($result);

			$voluntario = $registro['nome'];

			$query = "SELECT r.regiao, r.quant_beneficiados FROM regiao r, voluntarios v, voluntarios_has_regiao vr WHERE r.regiao = vr.regiao_regiao AND v.id_voluntarios = vr.voluntarios_id_voluntarios AND v.id_voluntarios = '$id_voluntario'"; 
			$result = @mysqli_query($link, $query);

			echo '<table class="table table-striped table-bordered table-hover">';
			echo '<tr>';
			echo '<td> <h2> N° </h2> </td>';
			echo '<td> <h2>Regiões</h2> </td>';
			echo '<td> <h2> Opções </h2> </td>';
			echo '</tr>';

			$num2 = 1;
			while ($registro = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo '<td>'.$num2.'</td>';
				echo '<td> <i>'.$registro["regiao"].'</i></td>';
				$id_regiao = $registro["regiao"];
				echo '<td> <a href="../actions/excluir_regioes_do_voluntarios.php?idv='.$id_voluntario.'&idr='.$id_regiao.'"><span class="glyphicon glyphicon-trash"></span></a>';
				echo '</tr>';

				$num2 ++;
			}
			echo '<td colspan="3"><a href="adicionar_regioes_do_voluntario.php?id='.$id_voluntario.'">Adicionar região para '.$voluntario.'</a></td>';
			echo '</table>';
		?>
		</div><!-- container -->
	</div>
</body>
</html>