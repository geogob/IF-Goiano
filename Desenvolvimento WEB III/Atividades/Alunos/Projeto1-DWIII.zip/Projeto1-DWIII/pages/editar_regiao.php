<!DOCTYPE html>
<html>
<head>
	<title>Editar cachorro</title>
	<link rel="stylesheet" type="text/css" href="BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php

	include 'bar.php';
	//Realizando a conexão com o banco
	require '../Configuracoes/config.php'; 
	require '../Configuracoes/conexao.php';
	$link = DB_connect();

	$regiao = $_GET['regiao'];

	$query = "SELECT * FROM regiao WHERE regiao = '$regiao'";
	$result = @mysqli_query($link, $query);

	$registro = mysqli_fetch_assoc($result);

	$Qbene = $registro['quant_beneficiados'];

	if(isset($_POST['regiao'])){

		$regiaoed = $_POST['regiao'];
		$Qbeneed = $_POST['Qb'];

		$query = "UPDATE regiao SET regiao = '$regiaoed', quant_beneficiados = '$Qbeneed' WHERE regiao = '$regiao'";
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/regioes.php">';

		}else{
			echo "Não foi possível editar! Tente novamente.";
		}

	}


	?>
	<div class="row esp_cima">

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/pages/regioes.php">Regiões</a></li>
	  				<li class="breadcrumb-item active">Editar região</li>
			</ol>

		</div>

		<div class="container col-md-4 col-md-offset-4">

					<h2 class="page-header">Editar Região<?php echo $regiao; ?></h2>

					<!-- Criando formulário -->
					<div class="form-group">
						<form method="POST">
							<label for="regiao">
								Regiao:
							</label>
							<?php
								echo sprintf('<input type="text" name="regiao" class="form-control" id="regiao" placeholder="Digite a regiao" value="%s"', $regiao);
							?>
							<label for="Qbene">
								Quantidade de beneficiados:
							</label>
							<?php
								echo'<input type="number" name="Qb" class="form-control" id="Qbene" placeholder="Digite a quantidade de beneficiados" value=' . $Qbene . '>';
							?>

							<a href="http://localhost/Projeto1-DWIII/pages/regioes.php" class="btn btn-danger">Cancelar</a>
							<input type="submit" value="Editar" class="btn btn-primary">

						</form>
						

					</div><!-- form -->

		</div>
</div>
</body>
</html>