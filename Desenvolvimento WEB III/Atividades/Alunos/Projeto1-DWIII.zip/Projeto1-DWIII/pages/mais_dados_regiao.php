<!DOCTYPE html>
<html>
<head>
	<title>Voluntários</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php
		include 'bar.php';
	?>

	<div class="row esp_cima" >

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/pages/regioes.php">Regiões</a></li>
	  				<li class="breadcrumb-item active">Mais dados da região</li>
			</ol>

		</div>

		<div class="container col-md-4 col-md-offset-4">
			<?php
			//Realizando a conexão com o banco
			require '../Configuracoes/config.php'; 
			require '../Configuracoes/conexao.php';
			$link = DB_connect();

			$regiao = $_GET['regiao'];

			$query = "SELECT regiao FROM regiao WHERE regiao = '$regiao'";
			$result = @mysqli_query($link, $query);

			$registro = mysqli_fetch_assoc($result);

			$regiao = $registro['regiao'];

			echo '<h1 class="page-header">'.$regiao.'</h1>';

				//Consulta SQL de inserção:



			$query = "SELECT v.id_voluntarios, v.nome FROM voluntarios v, regiao r, voluntarios_has_regiao vr WHERE v.id_voluntarios = vr.voluntarios_id_voluntarios AND r.regiao = vr.regiao_regiao AND r.regiao = '$regiao';"; 
			$result = @mysqli_query($link, $query);

			echo '<table class="table table-striped table-bordered table-hover">';
			echo '<tr>';
			echo '<td> <h2> N° </h2> </td>';
			echo '<td> <h2> Voluntários localizados nesta área </h2> </td>';
			echo '</tr>';

			$num = 1;
			while ($registro = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo '<td>'.$num.'</td>';
				echo '<td> <i>'.$registro["nome"].'</i></td>';
				$id_voluntario = $registro["id_voluntarios"];
				echo '</tr>';

				$num ++;
			}
			echo '</table>';
		?>
		</div><!-- container -->
	</div>
</body>
</html>