<!DOCTYPE html>
<html>
<head>
	<title>Voluntários</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php
		include 'bar.php';
	?>

	<div class="row esp_cima">

		
			<div class="container col-md-8 col-md-offset-2">
				<ol class="breadcrumb">
		  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
		  				<li class="breadcrumb-item active">Voluntários</li>
				</ol>
			</div>

		<div class="container col-md-6 col-md-offset-2">

			<?php 
			    //Realizando a conexão com o banco
			    require '../Configuracoes/config.php'; 
			    require '../Configuracoes/conexao.php';
			    $link = DB_connect();
				//Consulta SQL de inserção:
				$query = "SELECT * FROM voluntarios"; 
				$result = @mysqli_query($link, $query);
				echo '<table class="table table-striped table-bordered table-hover">';
				echo '<tr>';
				echo '<td> <h2> N° </h2> </td>';
				echo '<td> <h2> Nome </h2> </td>';
				echo '<td> <h2> Idade </h2></td>';
				echo '<td> <h2> Sexo </h2> </td>';
				echo '<td colspan="4"> <h2> Opções </h2> </td>';
				echo '</tr>';

				$num = 1;
				while ($registro = mysqli_fetch_assoc($result)) {
					echo '<tr>';
					echo '<td>'.$num.'</td>';
					echo '<td> <i>'.$registro["nome"].'</i></td>';
					echo '<td> <b>'.$registro["idade"].'</b> </td>';
					echo '<td> <b>'.$registro["sexo"].'</b> </td>';
					$id = $registro["id_voluntarios"];
					echo '<td> <a href="../actions/excluir_voluntarios.php?id='.$id.'"><span class="glyphicon glyphicon-trash"></span></a>';
					echo '<td> <a href="../pages/editar_voluntarios.php?id='.$id.'"><span class="glyphicon glyphicon-pencil"></span></a>';
					echo '<td> <a href="mais_dados_voluntario.php?id='.$id.'"><span class="glyphicon glyphicon-option-horizontal"></span></a>';
					echo '</tr>';
					$num ++;
				}
				echo '</table>';
			    //Fecha Conexão	
			?>
		</div><!-- container -->
		<div class="container col-md-4">
			<div class="fixed colo">

				<h2 class="page-header">Cadastro de voluntário</h2>

				<!-- Criando formulário -->
				<div class="form-group ">
					<form method="POST">
						<label for="nome">
							Nome:
						</label>
						<input type="text" name="nome" class="form-control" id="nome" placeholder="Digite o nome do voluntário">
						<label for="idade">
							Idade:
						</label>
						<input type="number" name="idade" class="form-control" id="idade" placeholder="Digite a idade do voluntário">
						<label>
							Sexo:
						</label>
						<div class="radio" id="sexo">
							<label>
								<input type="radio" name="sexo" value="Masculino" >Masculino
							</label>
							<label>
								<input type="radio" name="sexo" value="Feminino" >Feminino
							</label>
						</div><!-- radio -->
						<input type="submit" value="Cadastrar" class="btn btn-primary">

					</form>

				</div><!-- form -->
			</div>

			<?php


				if (isset($_POST['nome'])) {
					 
					//Recebe 
					$nome = $_POST['nome'];
					$idade = $_POST['idade'];
					$sexo = $_POST['sexo'];

					//Consulta SQL de inserção:
					$query = "INSERT INTO voluntarios (nome, idade, sexo) VALUES ('$nome', '$idade', '$sexo')";
					$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

					if($result){
						echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/voluntarios.php">';
					}else{
						echo '<p class="erro">Erro ao cadastrar $nome</p>';
					}
					   //Fecha Conexão	
					   DB_Close($link);
				}

			?>
		</div><!-- container -->
	</div><!-- row -->

</body>
</html>