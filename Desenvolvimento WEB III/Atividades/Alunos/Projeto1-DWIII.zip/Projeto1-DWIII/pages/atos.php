<!DOCTYPE html>
<html>
<head>
	<title>Atos Voluntários</title>
	<link rel="stylesheet" type="text/css" href="../BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php 
	include 'bar.php';

	 ?>

	<div class="row esp_cima">

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item active">Atos</li>
			</ol>

		</div>

		<div class="container col-md-offset-3">

			<div class="container col-md-5">


				<?php 
				    //Realizando a conexão com o banco
				    require '../Configuracoes/config.php'; 
				    require '../Configuracoes/conexao.php';
				    $link = DB_connect();

					//Consulta SQL de inserção:
					$query = "SELECT * FROM atos"; 
					$result = @mysqli_query($link, $query);
					echo '<table class="table table-striped table-bordered table-hover">';
					echo '<tr>';
					echo '<td> <h2> N° </h2> </td>';
					echo '<td> <h2> Ato voluntário </h2> </td>';
					echo '<td colspan="3"> <h2> Opções </h2> </td>';
					echo '</tr>';

					$num = 1;
					while ($registro = mysqli_fetch_assoc($result)) {
						echo '<tr>';
						echo '<td>'.$num.'</td>';
						echo '<td>'.$registro["ato"].'</td>';
						$id = $registro["id_ato"];
						echo '<td> <a href="../actions/excluir_ato.php?id='.$id.'"><span class="glyphicon glyphicon-trash"></span></a> </td>';
						echo '<td> <a href="../pages/editar_ato.php?id='.$id.'"><span class="glyphicon glyphicon-pencil"></span></a> </td>';
						echo '<td> <a href="mais_dados_ato.php?id='.$id.'"><span class="glyphicon glyphicon-option-horizontal"></span></a> </td>';
						echo '</tr>';

						$num ++;
					}
					echo '</table>';

				?>
			</div>
			<div class="container col-md-2">
				<div class="fixed">
					<h1>Cadastro de ato voluntário</h1>


						<div class="form-group">
							<!-- Criando formulário -->
							<form method="POST">
								<label>
									Ato:
								</label>
								<input type="text" name="ato" class="form-control"><br/>
								<input type="submit" value="Cadastrar" class="btn btn-primary">

							</form>

						</div>

						<?php


							if (isset($_POST['ato'])) {

							    //Recebe 
							    $ato = $_POST['ato'];

								//Consulta SQL de inserção:
								$query = "INSERT INTO atos (ato) VALUES ('$ato')";
								$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

								if($result){
									echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/atos.php">';
								}else{
									echo "Erro ao cadastrar o ato de $ato";
								}
							    
							}

							//Fecha Conexão	
							DB_Close($link);

						?>
					</div>
			</div>
		</div>
	</div>
</body>
</html>