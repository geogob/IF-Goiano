<!DOCTYPE html>
<html>
<head>
	<title>Editar cachorro</title>
	<link rel="stylesheet" type="text/css" href="BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<?php

	include 'bar.php';
	//Realizando a conexão com o banco
	require '../Configuracoes/config.php'; 
	require '../Configuracoes/conexao.php';
	$link = DB_connect();

	$id = $_GET['id'];

	$query = "SELECT * FROM atos WHERE id_ato = '$id'";
	$result = @mysqli_query($link, $query);

	$registro = mysqli_fetch_assoc($result);

	$ato = $registro['ato'];

	if(isset($_POST['ato'])){

		$atoed = $_POST['ato'];

		$query = "UPDATE atos SET ato = '$atoed' WHERE id_ato = '$id'";
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=http://localhost/Projeto1-DWIII/pages/atos.php">';

		}else{
			echo "Não foi possível editar! Tente novamente.";
		}

	}


	?>
	<div class="row esp_cima">

		<div class="container col-md-8 col-md-offset-2">

			<ol class="breadcrumb">
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/index.php">Principal</a></li>
	  				<li class="breadcrumb-item"><a href="http://localhost/Projeto1-DWIII/pages/atos.php">Atos</a></li>
	  				<li class="breadcrumb-item active">Editar ato</li>
			</ol>

		</div>

		<div class="container col-md-4 col-md-offset-4">

					<h2 class="page-header">Editar ato</h2>

					<!-- Criando formulário -->
					<div class="form-group">
						<form method="POST">
							<label for="ato">
								Ato:
							</label>

							<div>
							<?php
								echo sprintf('<input type="text" name="ato" class="form-control" id="ato" placeholder="Digite o ato" value="%s"', $ato);
							?>
							</div>
							<a href="http://localhost/Projeto1-DWIII/pages/atos.php" class="btn btn-danger">Cancelar</a>
							<input type="submit" value="Editar" class="btn btn-primary">

						</form>

					</div><!-- form -->

		</div>
</div>
</body>
</html>