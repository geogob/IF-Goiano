-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: trabalho_volutario
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atos`
--

DROP TABLE IF EXISTS `atos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atos` (
  `id_ato` int(11) NOT NULL AUTO_INCREMENT,
  `ato` varchar(100) NOT NULL,
  PRIMARY KEY (`id_ato`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atos`
--

LOCK TABLES `atos` WRITE;
/*!40000 ALTER TABLE `atos` DISABLE KEYS */;
INSERT INTO `atos` VALUES (8,'Capinar'),(9,'Cuidar de criança'),(10,'Cuidar de cachorro'),(11,'Recolher lixo');
/*!40000 ALTER TABLE `atos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiao`
--

DROP TABLE IF EXISTS `regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiao` (
  `regiao` varchar(50) NOT NULL,
  `quant_beneficiados` int(11) NOT NULL,
  PRIMARY KEY (`regiao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiao`
--

LOCK TABLES `regiao` WRITE;
/*!40000 ALTER TABLE `regiao` DISABLE KEYS */;
INSERT INTO `regiao` VALUES ('Leste',20),('Norte',1),('Sudeste',10),('Sul ',15);
/*!40000 ALTER TABLE `regiao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios`
--

DROP TABLE IF EXISTS `voluntarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios` (
  `id_voluntarios` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `sexo` enum('Feminino','Masculino') NOT NULL,
  `idade` int(11) NOT NULL,
  PRIMARY KEY (`id_voluntarios`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios`
--

LOCK TABLES `voluntarios` WRITE;
/*!40000 ALTER TABLE `voluntarios` DISABLE KEYS */;
INSERT INTO `voluntarios` VALUES (1,'José Vinícius','Masculino',16),(4,'Felipe','Masculino',16),(5,'Lucas','Masculino',18),(7,'Junior','Masculino',17),(8,'Gabriely','Feminino',17),(10,'Fernando','Masculino',19),(12,'Rafaela','Feminino',24),(13,'Noilza','Feminino',42),(14,'Lorena','Feminino',17),(15,'Lys Laine','Feminino',18),(16,'João Pedro','Masculino',16),(17,'Igor','Masculino',18),(18,'Frederico','Masculino',27),(19,'Laís','Feminino',20),(20,'Allan','Masculino',44),(21,'Jesus','Masculino',48),(22,'Lucas','Masculino',16),(23,'Gabryela','Feminino',17),(24,'Juninho','Masculino',56);
/*!40000 ALTER TABLE `voluntarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios_has_atos`
--

DROP TABLE IF EXISTS `voluntarios_has_atos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios_has_atos` (
  `voluntarios_id_voluntarios` int(11) NOT NULL,
  `atos_id_ato` int(11) NOT NULL,
  PRIMARY KEY (`voluntarios_id_voluntarios`,`atos_id_ato`),
  KEY `fk_Volutarios_has_Atos_Atos1_idx` (`atos_id_ato`),
  KEY `fk_Volutarios_has_Atos_Volutarios1_idx` (`voluntarios_id_voluntarios`),
  CONSTRAINT `fk_Volutarios_has_Atos_Atos1` FOREIGN KEY (`atos_id_ato`) REFERENCES `atos` (`id_ato`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Volutarios_has_Atos_Volutarios1` FOREIGN KEY (`voluntarios_id_voluntarios`) REFERENCES `voluntarios` (`id_voluntarios`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios_has_atos`
--

LOCK TABLES `voluntarios_has_atos` WRITE;
/*!40000 ALTER TABLE `voluntarios_has_atos` DISABLE KEYS */;
INSERT INTO `voluntarios_has_atos` VALUES (1,8),(4,10),(5,11),(7,10);
/*!40000 ALTER TABLE `voluntarios_has_atos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios_has_regiao`
--

DROP TABLE IF EXISTS `voluntarios_has_regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios_has_regiao` (
  `voluntarios_id_voluntarios` int(11) NOT NULL,
  `regiao_regiao` varchar(50) NOT NULL,
  PRIMARY KEY (`voluntarios_id_voluntarios`,`regiao_regiao`),
  KEY `fk_Volutarios_has_Regiao_Regiao1_idx` (`regiao_regiao`),
  KEY `fk_Volutarios_has_Regiao_Volutarios1_idx` (`voluntarios_id_voluntarios`),
  CONSTRAINT `fk_Volutarios_has_Regiao_Regiao1` FOREIGN KEY (`regiao_regiao`) REFERENCES `regiao` (`regiao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Volutarios_has_Regiao_Volutarios1` FOREIGN KEY (`voluntarios_id_voluntarios`) REFERENCES `voluntarios` (`id_voluntarios`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios_has_regiao`
--

LOCK TABLES `voluntarios_has_regiao` WRITE;
/*!40000 ALTER TABLE `voluntarios_has_regiao` DISABLE KEYS */;
INSERT INTO `voluntarios_has_regiao` VALUES (1,'Sudeste'),(1,'Sul '),(5,'Sul '),(7,'Sudeste');
/*!40000 ALTER TABLE `voluntarios_has_regiao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-25 20:36:15
