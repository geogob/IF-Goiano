<!DOCTYPE html>
<html>
<head>
	<title>Trabalho voluntário</title>
	<link rel="stylesheet" type="text/css" href="BootStrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>

		<div class="conteudo">

			<h1 class="page-header">Seja bem vindo ao sistema de controle de Trabalho voluntário, José!</h1>
			<p>O que deseja fazer?</p>

			<ul>
				<li><a href="pages/voluntarios.php">Ver nossos voluntários</a></li>
				<li><a href="pages/atos.php">Ver atos voluntários que praticamos</a></li>
				<li><a href="pages/regioes.php">Ver regiões onde atuamos</a></li>
			</ul>

		</div>
</body>
</html>