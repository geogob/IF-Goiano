<?php

	define('DB_HOSTNAME', 'localhost'); //Nome de HOST
	define('DB_USERNAME', 'root'); //Usuário
	define('DB_PASSWORD', 'ifgoiano'); //Senha
	define('DB_DATABASE', 'voluntarios'); //Nome do Banco de Dados
	define('DB_CHARSET', 'utf8');
	
	//Abrindo conexão
	function DB_connect()
	{
		$link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE) or die(mysqli_connect_error());

		mysqli_set_charset($link, DB_CHARSET) or die(mysqli_connect_error($link));

		return $link;
	}

	//Fechando conexão
	function DB_close($link)
	{
		mysqli_close($link) or die(mysqli_error($link));
	}

?>