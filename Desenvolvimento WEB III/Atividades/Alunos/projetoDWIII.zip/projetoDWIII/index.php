<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/voluntario.css">
</head>
<body>

	<div class="container">
		<div>
			<h1 class="voluntario"><a href="index.php">Voluntários</a></h1>
		</div>
	</div>

	<nav class="menu">
		<div class="container">
			<ul >
				<li class="menu_item ativo"><a href="#">Voluntários</a></li>
				<li class="menu_item"><a href="cadastrarVoluntario.php">Cadastrar voluntário</a></li>
				<li class="menu_item"><a href="gerenciarAtoCidade.php">Gerenciar atos e cidades</a></li>
				<li class="menu_item"><a href="vincularAtoCidade.php">Gerenciar atos e cidades dos voluntários</a></li>
			</ul>	
		</div>
	</nav>

	<div class="container">

		<ol class="breadcrumb">
		  <li class="active">Home</li>
		</ol>
		
		<div >
			<h2 id="consulta">Consulta de voluntários</h2><br>

			<?php

				//Realizando a conexão com o banco
			    require 'conexaoDB.php';
			    $link = DB_connect();

			    //Verificando se houve o envio
				if(isset($_GET['id_voluntario'])){

				//Recebe 
			    $id_voluntario= $_GET['id_voluntario'];

				//SQL de consulta de vínculo voluntário/ato
			    $queryVerificarVoluntarioAto = "SELECT voluntario_id_voluntario FROM voluntario_atos WHERE voluntario_id_voluntario='$id_voluntario'"; 
				$resultVerificarVoluntarioAto = @mysqli_query($link, $queryVerificarVoluntarioAto);

				//SQL de consulta de vínculo voluntário/cidade
				$queryVerificarVoluntarioRegiao = "SELECT voluntario_id_voluntario FROM voluntario_regiao WHERE voluntario_id_voluntario='$id_voluntario'"; 
				$resultVerificarVoluntarioRegiao = @mysqli_query($link, $queryVerificarVoluntarioRegiao);

				//Verificando se o resultado está vazio
				if(!empty($resultVerificarVoluntarioAto) && empty($resultVerificarVoluntarioRegiao)){
					$registroVerificarVoluntarioAto = mysqli_fetch_assoc($resultVerificarVoluntarioAto);
					$registroVerificarVoluntarioRegiao = mysqli_fetch_assoc($resultVerificarVoluntarioRegiao);

					//Verificando se esse voluntário está associado a um ato
					if($registroVerificarVoluntarioAto['voluntario_id_voluntario'] == $id_voluntario){

						echo "<div class='alert alert-danger' role='alert'>
			  				Esse voluntário está vínculado a uma cidade ou ato e não pode ser deletado.
						</div>";

					//Verificando se esse voluntário está associado a uma cidade
					}else if($registroVerificarVoluntarioRegiao['voluntario_id_voluntario'] == $id_voluntario){

						echo "<div class='alert alert-danger' role='alert'>
			  				Esse voluntário está vínculado a uma cidade ou ato e não pode ser deletado.
						</div>";

					}else{
						//SQL de exclusão da cidade
						$queryDeleteVoluntario = "DELETE FROM voluntario WHERE id_voluntario = '$id_voluntario'"; 
						$resultDeleteVoluntario = @mysqli_query($link, $queryDeleteVoluntario) or die(mysqli_connect_error($link));
						if($resultDeleteVoluntario){
							echo "<div class='alert alert-success' role='alert'>
				  				Voluntário deletado com sucesso!
							</div>";
							
						}else{
							echo "<div class='alert alert-danger' role='alert'>
				  				Deu ruim!
							</div>";
						}
					}
				}
			}

			?>

			<table class="table table-bordered">
				<thead>
					<tr>
						<td>#</td>
						<td>Nome</td>
						<td>Idade</td>
						<td>Sexo</td>
						<td>Opções</td>
					</tr>
				</thead>
				<tbody>
					<?php

					//SQL de consulta de voluntários
					$querySelecionarVoluntario = "SELECT * FROM voluntario"; 
					$resultSelecionarVoluntario = @mysqli_query($link, $querySelecionarVoluntario);

					//Preenchendo tabela de voluntários
					while ($registroSelecionarVoluntario = mysqli_fetch_assoc($resultSelecionarVoluntario)) {

						//Montando a tabela
						echo '<tr>';
						echo '<td>'.$registroSelecionarVoluntario["id_voluntario"].'</td>';
						echo '<td>'.$registroSelecionarVoluntario["nome"].'</td>';
						echo '<td>'.$registroSelecionarVoluntario["idade"].'</td>';
						echo '<td>'.$registroSelecionarVoluntario["sexo"].'</td>';
						echo '<td><a href="index.php?id_voluntario='.$registroSelecionarVoluntario["id_voluntario"].'"><span style="margin-left:30px;" class="glyphicon glyphicon-trash"></span></a>
						<a href="editarVoluntario.php?id_voluntario='.$registroSelecionarVoluntario["id_voluntario"].'"><span style="margin-left:30px;" class="glyphicon glyphicon-pencil"></span></a>
						</td>';
						echo '</tr>';

					}

				    //Fecha Conexão	
				    DB_Close($link);
				    ?>
				</tbody>
			</table>
		</div><br>
	</div>
</body>
</html>