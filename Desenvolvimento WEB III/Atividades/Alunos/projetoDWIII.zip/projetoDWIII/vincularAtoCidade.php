<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios: Vincular Atos e cidades</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/voluntario.css">
</head>
<body>

	<div class="container">
		<div>
			<h1 class="voluntario"><a href="index.php">Voluntários</a></h1>
		</div>
	</div>

	<nav class="menu">
		<div class="container">
			<ul >
				<li class="menu_item"><a href="index.php">Voluntários</a></li>
				<li class="menu_item"><a href="cadastrarVoluntario.php">Cadastrar voluntário</a></li>
				<li class="menu_item"><a href="gerenciarAtoCidade.php">Gerenciar atos e cidades</a></li>
				<li class="menu_item ativo"><a href="#">Gerenciar atos e cidades dos voluntários</a></li>
			</ul>	
		</div>
	</nav>

	<div class="container">

		<ol class="breadcrumb">
		  <li><a href="index.php">Home</a></li>
		  <li class="active">Gerenciar atos e cidades dos voluntários</li>
		</ol>
		
		<div class="row">
			<div class="col-sm-6">
				<form action="vincularAtoCidade.php" method="post">

					<h2>Voluntários e seus atos</h2><br>

					<?php

						//Realizando a conexão com o banco
					    require 'conexaoDB.php';
					    $link = DB_connect();

					    //Verificando se houve o envio
					    if(isset($_POST['voluntarioAto'])){

							//Recebe 
							$voluntario= $_POST['voluntarioAto'];
							$ato= $_POST['ato']; 

							//Verificando se os campos foram selecionados
							if($voluntario == 0){

								echo "<div class='alert alert-danger' role='alert'>
						  				Selecione o voluntário e o ato.
									</div>";

							}else if($ato == 0){

								echo "<div class='alert alert-danger' role='alert'>
						  				Selecione o voluntário e o ato.
									</div>";

							}else{

								//SQL de inserção do voluntário e do ato
								$queryInsertVoluntarioAto = "INSERT INTO voluntario_atos (voluntario_id_voluntario, atos_id_ato) VALUES ('$voluntario', '$ato')";
								$resultInsertVoluntarioAto = @mysqli_query($link, $queryInsertVoluntarioAto) or die(mysqli_error($link));

								if($resultInsertVoluntarioAto){

									echo "<div class='alert alert-success' role='alert'>
							  				Vínculo realizado com sucesso!
										</div>";

								}else{
									echo "<div class='alert alert-danger' role='alert'>
						  				Deu ruim!
									</div>";
								}
							}
						}

						//Verificando se houve o envio
						if(isset($_GET['id_voluntarioVA'])){

							//Recebe
							$id_voluntario=$_GET['id_voluntarioVA'];
							$id_ato=$_GET['id_atoVA'];

							//SQL de exclusão do vínculo Voluntário/Ato
							$queryDeleteVoluntarioAto = "DELETE FROM voluntario_atos WHERE voluntario_id_voluntario = '$id_voluntario' AND atos_id_ato = '$id_ato'"; 
							$resultDeleteVoluntarioAto = @mysqli_query($link, $queryDeleteVoluntarioAto) or die(mysqli_connect_error($link));

							if($resultDeleteVoluntarioAto){
								echo "<div class='alert alert-success' role='alert'>
					  				Vínculo deletado com sucesso!
								</div>";
								
							}else{
								echo "<div class='alert alert-danger' role='alert'>
						  				Deu ruim!
									</div>";
							}

						}

					?>

					<table class="table table-bordered">
						<thead>
							<tr>
								<td>Nome do voluntário</td>
								<td>Nome do ato</td>
								<td>Opções</td>
							</tr>
						</thead>
						<tbody>
							<?php

								//SQL de consulta de voluntários e seus atos
								$querySelectVoluntarioAtos = "SELECT * FROM voluntario_atos"; 
								$resultSelectVoluntarioAtos = @mysqli_query($link, $querySelectVoluntarioAtos);

								//Verificando se o resultado está vazio
								if(!empty($resultSelectVoluntarioAtos)){

									//Preenchendo tabela com os voluntários e atos
									while ($registroSelectVoluntarioAtos = mysqli_fetch_assoc($resultSelectVoluntarioAtos)){

									//SQL dos voluntários
									$queryVoluntarioVA = 'SELECT nome FROM voluntario WHERE id_voluntario="'.$registroSelectVoluntarioAtos['voluntario_id_voluntario'].'"'; 
									$resultVoluntarioVA = @mysqli_query($link, $queryVoluntarioVA);
									$registroVoluntarioVA = mysqli_fetch_assoc($resultVoluntarioVA);

									//SQL dos atos
									$queryAtoVA = 'SELECT nome FROM atos WHERE id_ato="'.$registroSelectVoluntarioAtos['atos_id_ato'].'"'; 
									$resultAtoVA = @mysqli_query($link, $queryAtoVA);
									$registroAtoVA = mysqli_fetch_assoc($resultAtoVA);

									//Montando a tabela
									echo '<tr>';
									echo '<td>'.$registroVoluntarioVA['nome'].'</td>';
									echo '<td>'.$registroAtoVA['nome'].'</td>';
									echo '<td><a href="vincularAtoCidade.php?id_voluntarioVA='.$registroSelectVoluntarioAtos["voluntario_id_voluntario"].'&id_atoVA='.$registroSelectVoluntarioAtos["atos_id_ato"].'"><span style="margin-left:20px;" class="glyphicon glyphicon-trash"></span></a></td>';
									echo '</tr>';

									}

								}
								
						    ?>
						</tbody>
					</table>
				    <br>

					<div class="row">
						<div class="col-sm-6">
							<label>Voluntário:</label>
							<select class="form-control" name="voluntarioAto">
								<option value="0">Selecione um voluntário</option>
								<?php

									//SQL dos voluntários
									$queryVoluntario = "SELECT * FROM voluntario"; 
									$resultVoluntario = @mysqli_query($link, $queryVoluntario);

									//Verificando de houve resultado
									if(!empty($resultVoluntario)){

										//Preenchendo select com os voluntários
										while ($registroVoluntario = mysqli_fetch_assoc($resultVoluntario)) {
											
											echo '<option value="'.$registroVoluntario["id_voluntario"].'">'.$registroVoluntario["nome"].'</option>';
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-6">
							<label>Ato:</label>
							<select class="form-control" name="ato">
								<option value="0">Selecione o ato</option>
								<?php

									//SQL dos atos
									$queryAto = "SELECT * FROM atos"; 
									$resultAto = @mysqli_query($link, $queryAto);

									//Verificando de houve resultado
									if(!empty($resultAto)){

										//Preenchendo select com os atos
										while ($registroAto = mysqli_fetch_assoc($resultAto)) {
									
											echo '<option value="'.$registroAto["id_ato"].'">'.$registroAto["nome"].'</option>';

										}
									}
								?>
							</select>
						</div>
					</div>
					<br>
					<button style="margin-top:10px;" type="submit" class="btn botao">Vincular Ato</button>
				</form>
			</div>
			<div class="col-sm-6">
				<form action="vincularAtoCidade.php" method="post">

					<h2>Voluntários e suas cidades</h2><br>

					<?php

						//Verificando se houve o envio
						if(isset($_POST['voluntarioCidade'])){

							//Recebe 
							$voluntario= $_POST['voluntarioCidade'];
							$cidade= $_POST['cidade']; 

							//Verificando se os campos foram selecionados
							if($voluntario == 0){
								
								echo "<div class='alert alert-danger' role='alert'>
						  				Selecione o voluntário e a cidade.
									</div>";

							}else if($cidade == "nenhuma"){

								echo "<div class='alert alert-danger' role='alert'>
						  				Selecione o voluntário e a cidade.
									</div>";

							}else{
								//SQL de inserção do voluntário e do ato
								$queryInsertVoluntarioCidade = "INSERT INTO voluntario_regiao (voluntario_id_voluntario, regiao_nome) VALUES ('$voluntario', '$cidade')";
								$resultInsertVoluntarioCidade = @mysqli_query($link, $queryInsertVoluntarioCidade) or die(mysqli_error($link));

								if($resultInsertVoluntarioCidade){

									echo "<div class='alert alert-success' role='alert'>
							  				Vínculo realizado com sucesso!
										</div>";

								}else{
									echo "<div class='alert alert-danger' role='alert'>
						  				Deu ruim!
									</div>";
								}
							}
						}

						//Verificando se houve o envio
						if(isset($_GET['id_voluntarioVC'])){

							//Recebe
							$id_voluntario=$_GET['id_voluntarioVC'];
							$cidade=$_GET['id_cidadeVC'];

							//SQL de exclusão do vínculo Voluntário/Ato
							$queryDeleteVoluntarioAto = "DELETE FROM voluntario_regiao WHERE voluntario_id_voluntario = '$id_voluntario' AND regiao_nome = '$cidade'"; 
							$resultDeleteVoluntarioAto = @mysqli_query($link, $queryDeleteVoluntarioAto) or die(mysqli_connect_error($link));
							if($resultDeleteVoluntarioAto){
								echo "<div class='alert alert-success' role='alert'>
					  				Vínculo deletado com sucesso!
								</div>";
								
							}else{
								echo "<div class='alert alert-danger' role='alert'>
						  				Deu ruim!
									</div>";
							}

						}
					?>

					<table class="table table-bordered">
						<thead>
							<tr>
								<td>Nome do voluntário</td>
								<td>Nome da cidade</td>
								<td>Deletar</td>
							</tr>
						</thead>
						<tbody>
							<?php

								//SQL de consulta de voluntário/região
								$querySelecVoluntarioRegiao = "SELECT * FROM voluntario_regiao"; 
								$resultSelecVoluntarioRegiao = @mysqli_query($link, $querySelecVoluntarioRegiao);

								//Verificando se o resultado está vazio
								if(!empty($resultSelecVoluntarioRegiao)){

									//Preenchendo tabela com os voluntários e cidades
									while ($registroSelecVoluntarioRegiao = mysqli_fetch_assoc($resultSelecVoluntarioRegiao)){

									//SQL dos voluntários
									$queryVoluntarioVC = 'SELECT nome FROM voluntario WHERE id_voluntario="'.$registroSelecVoluntarioRegiao['voluntario_id_voluntario'].'"'; 
									$resultVoluntarioVC = @mysqli_query($link, $queryVoluntarioVC);
									$registroVoluntarioVC = mysqli_fetch_assoc($resultVoluntarioVC);

									//SQL das regiões
									$queryCidadeVC = 'SELECT nome FROM regiao WHERE nome="'.$registroSelecVoluntarioRegiao['regiao_nome'].'"'; 
									$resultCidadeVC = @mysqli_query($link, $queryCidadeVC);
									$registroCidadeVC = mysqli_fetch_assoc($resultCidadeVC);

									//Montando a tabela
									echo '<tr>';
									echo '<td>'.$registroVoluntarioVC['nome'].'</td>';
									echo '<td>'.$registroCidadeVC['nome'].'</td>';
									echo '<td><a href="vincularAtoCidade.php?id_voluntarioVC='.$registroSelecVoluntarioRegiao["voluntario_id_voluntario"].'&id_cidadeVC='.$registroSelecVoluntarioRegiao["regiao_nome"].'"><span style="margin-left:20px;" class="glyphicon glyphicon-trash"></span></a></td>';
									echo '</tr>';

									}

								}

						    ?>
						</tbody>
					</table>
				    <br>

				    <div class="row">
						<div class="col-sm-6">
							<label>Voluntário:</label>
							<select class="form-control" name="voluntarioCidade">
								<option value="0">Selecione um voluntário</option>
								<?php

									//SQL dos voluntários
									$queryVoluntario = "SELECT * FROM voluntario"; 
									$resultVoluntario = @mysqli_query($link, $queryVoluntario);

									//Verificando de houve resultado
									if(!empty($resultVoluntario)){

										//Preenchendo select com os voluntários
										while ($registroVoluntario = mysqli_fetch_assoc($resultVoluntario)) {
											
											echo '<option value="'.$registroVoluntario["id_voluntario"].'">'.$registroVoluntario["nome"].'</option>';
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-6">
							<label>Cidade:</label>
							<select class="form-control" name="cidade">
								<option value="nenhuma">Selecione a cidade</option>
								<?php

									//SQL das regiões
									$queryRegiao = "SELECT * FROM regiao"; 
									$resultRegiao = @mysqli_query($link, $queryRegiao);

									//Verificando de houve resultado
									if(!empty($resultRegiao)){

										//Preenchendo select com as regiões
										while ($registroRegiao = mysqli_fetch_assoc($resultRegiao)) {
									
											echo '<option value="'.$registroRegiao["nome"].'">'.$registroRegiao["nome"].'</option>';

										}
									}

									//Fecha Conexão	
								    DB_Close($link);
								?>
							</select>
						</div>
					</div>
					<br>
					<button style="margin-top:10px;" type="submit" class="btn botao">Vincular cidade</button>

				</form>
			</div>
		</div>
	</div>
</body>
</html>