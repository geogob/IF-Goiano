-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: voluntarios
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atos`
--

DROP TABLE IF EXISTS `atos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atos` (
  `id_ato` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`id_ato`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atos`
--

LOCK TABLES `atos` WRITE;
/*!40000 ALTER TABLE `atos` DISABLE KEYS */;
INSERT INTO `atos` VALUES (1,'Ajudar idosos'),(2,'Limpeza'),(3,'Carpir');
/*!40000 ALTER TABLE `atos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiao`
--

DROP TABLE IF EXISTS `regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiao` (
  `nome` varchar(50) NOT NULL,
  `qnt_pessoas` int(11) NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiao`
--

LOCK TABLES `regiao` WRITE;
/*!40000 ALTER TABLE `regiao` DISABLE KEYS */;
INSERT INTO `regiao` VALUES ('Anápolis-GO',1000000000),('Iaciara-GO',4684),('Posse-GO',15678);
/*!40000 ALTER TABLE `regiao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntario`
--

DROP TABLE IF EXISTS `voluntario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntario` (
  `id_voluntario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `idade` int(3) NOT NULL,
  PRIMARY KEY (`id_voluntario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntario`
--

LOCK TABLES `voluntario` WRITE;
/*!40000 ALTER TABLE `voluntario` DISABLE KEYS */;
INSERT INTO `voluntario` VALUES (1,'Fernando','Masculino',19),(2,'Lys Layane','Feminino',18),(3,'George Barros','Masculino',25);
/*!40000 ALTER TABLE `voluntario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntario_atos`
--

DROP TABLE IF EXISTS `voluntario_atos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntario_atos` (
  `voluntario_id_voluntario` int(11) NOT NULL,
  `atos_id_ato` int(11) NOT NULL,
  PRIMARY KEY (`voluntario_id_voluntario`,`atos_id_ato`),
  KEY `fk_voluntario_has_atos_atos1_idx` (`atos_id_ato`),
  KEY `fk_voluntario_has_atos_voluntario_idx` (`voluntario_id_voluntario`),
  CONSTRAINT `fk_voluntario_has_atos_atos1` FOREIGN KEY (`atos_id_ato`) REFERENCES `atos` (`id_ato`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_voluntario_has_atos_voluntario` FOREIGN KEY (`voluntario_id_voluntario`) REFERENCES `voluntario` (`id_voluntario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntario_atos`
--

LOCK TABLES `voluntario_atos` WRITE;
/*!40000 ALTER TABLE `voluntario_atos` DISABLE KEYS */;
INSERT INTO `voluntario_atos` VALUES (2,1),(3,1),(3,3);
/*!40000 ALTER TABLE `voluntario_atos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntario_regiao`
--

DROP TABLE IF EXISTS `voluntario_regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntario_regiao` (
  `voluntario_id_voluntario` int(11) NOT NULL,
  `regiao_nome` varchar(50) NOT NULL,
  PRIMARY KEY (`voluntario_id_voluntario`,`regiao_nome`),
  KEY `fk_voluntario_has_regiao_regiao1_idx` (`regiao_nome`),
  KEY `fk_voluntario_has_regiao_voluntario1_idx` (`voluntario_id_voluntario`),
  CONSTRAINT `fk_voluntario_has_regiao_regiao1` FOREIGN KEY (`regiao_nome`) REFERENCES `regiao` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_voluntario_has_regiao_voluntario1` FOREIGN KEY (`voluntario_id_voluntario`) REFERENCES `voluntario` (`id_voluntario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntario_regiao`
--

LOCK TABLES `voluntario_regiao` WRITE;
/*!40000 ALTER TABLE `voluntario_regiao` DISABLE KEYS */;
INSERT INTO `voluntario_regiao` VALUES (1,'Posse-GO'),(2,'Posse-GO'),(3,'Posse-GO');
/*!40000 ALTER TABLE `voluntario_regiao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-25 19:56:05
