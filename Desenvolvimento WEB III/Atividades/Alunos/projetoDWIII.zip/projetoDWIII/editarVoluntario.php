<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios:Editar Voluntário</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/voluntario.css">
</head>
<body>

	<div class="container">
		<div >
			<h1 class="voluntario"><a href="index.php">Voluntários</a></h1>
		</div>
	</div>

	<nav class="menu">
		<ul >
			<li class="menu_item primeiro"><a href="index.php">Voluntários</a></li>
			<li class="menu_item"><a href="cadastrarVoluntario.php">Cadastrar voluntário</a></li>
			<li class="menu_item"><a href="gerenciarAtoCidade.php">Gerenciar atos e cidades</a></li>
			<li class="menu_item"><a href="vincularAtoCidade.php">Gerenciar atos e cidades dos voluntários</a></li>
		</ul>	
	</nav>
	<div class="container">

		<ol class="breadcrumb">
		  <li><a href="index.php">Home</a></li>
		  <li><a href="index.php">Consultar voluntários</a></li>
		  <li class="active">Editar Voluntário</li>
		</ol>
		
		<?php
		//Recebendo id_voluntario
		$id_voluntario = $_GET['id_voluntario'];

		echo '<form style="margin-top: 20px;" action="editarVoluntario.php?id_voluntario='.$id_voluntario.'" method="post" id="form">';
		?>
			<h2>Editar voluntário</h2><br>

			<?php

				//Realizando a conexão com o banco
			    require 'conexaoDB.php';
			    $link = DB_connect();

				//SQL de inserção:
				$querySelecionarVoluntario = "SELECT * FROM voluntario WHERE id_voluntario = '$id_voluntario'"; 
				$resultSelecionarVoluntario = @mysqli_query($link, $querySelecionarVoluntario);
				$registroSelecionarVoluntario = mysqli_fetch_assoc($resultSelecionarVoluntario);

				//Verificando se houve o envio
				if(isset($_POST['nome'])){
					
					//Verificando os campos
					if($_POST['nome'] != null && $_POST['idade'] != null && $_POST['sexo'] != null){

						//Recebe
						$nome = $_POST['nome'];
						$idade = $_POST['idade'];
						$sexo = $_POST['sexo'];

						//Consulta SQL de atualização do voluntário
						$queryAtualizarVoluntario = "UPDATE voluntario SET nome='$nome', idade='$idade', sexo='$sexo' WHERE id_voluntario='$id_voluntario'";
						$resultAtualizarVoluntario = @mysqli_query($link, $queryAtualizarVoluntario) or die(mysqli_error($link));

						if($resultAtualizarVoluntario){

							//Chamando a tela de consulta
							header("Location: index.php");
							exit;

						}else{
							echo "<div class='alert alert-danger' role='alert'>
					  				Deu ruim!
								</div>";
						}

					}else{
						echo "<div class='alert alert-danger' role='alert'>
						  		 Um ou mais campos não estão preenchidos.
							</div>";
					}
				}
			?>

			<div class="row">

				<div class="col-sm-8">
					<label>Nome:</label>
					<?php
					echo '<input class="form-control" type="text" name="nome" placeholder="Ex: Fernando Soares" value="'.$registroSelecionarVoluntario["nome"].'"><br>';
					?>
				</div>
				<div class="col-sm-4">
					<label>Idade:</label>
					<?php
					echo '<input class="form-control" type="text" name="idade" placeholder="Ex: 18" value="'.$registroSelecionarVoluntario["idade"].'">';
					?>
				</div>

			</div>

			<label style="margin-right:10px;">Sexo:</label>
			<?php
				if($registroSelecionarVoluntario["sexo"] == "Masculino"){
					echo '<label><input type="radio" name="sexo" value="Masculino" checked> Masculino</label>';
					echo '<label style="margin-left:10px"><input type="radio" name="sexo" value="Feminino"> Feminino</label><br>';
				}else{
					echo '<label><input type="radio" name="sexo" value="Masculino"> Masculino</label>';
					echo '<label style="margin-left:10px"><input type="radio" name="sexo" value="Feminino" checked> Feminino</label><br>';
				}
			?>

			<br>

			<button style="margin-top:10px;" class="btn botao" hfer="index.php">Cancelar</button>
			<button style="margin-top:10px;margin-left: 20px;" type="submit" class="btn botao">Salvar</button>

		</form>

	</div>
</body>
</html>