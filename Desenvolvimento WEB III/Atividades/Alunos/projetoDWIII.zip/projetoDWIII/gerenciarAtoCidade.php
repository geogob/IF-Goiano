<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios: Gerenciar Atos e cidades</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/voluntario.css">
</head>
<body>

	<div class="container">
		<div>
			<h1 class="voluntario"><a href="index.php">Voluntários</a></h1>
		</div>
	</div>

	<nav class="menu">
		<div class="container">
			<ul >
				<li class="menu_item"><a href="index.php">Voluntários</a></li>
				<li class="menu_item"><a href="cadastrarVoluntario.php">Cadastrar voluntário</a></li>
				<li class="menu_item ativo"><a href="#">Gerenciar atos e cidades</a></li>
				<li class="menu_item"><a href="vincularAtoCidade.php">Gerenciar atos e cidades dos voluntários</a></li>
			</ul>
		</div>	
	</nav>

	<div class="container">

		<ol class="breadcrumb">
		  <li><a href="index.php">Home</a></li>
		  <li class="active">Gerenciar atos e cidades</li>
		</ol>
		
		<div class="row">
			<div class="col-sm-6">
				<form action="gerenciarAtoCidade.php" method="post">

					<h2>Atos</h2><br>

					<?php

						//Realizando a conexão com o banco
					    require 'conexaoDB.php';
					    $link = DB_connect();

					    //Verificando se houve o envio
						if(isset($_POST['novoAto'])){

							//Recebe 
							$novoAto= $_POST['novoAto'];

							//SQL de inserção do ato
							$queryInsertAto = "INSERT INTO atos (nome) VALUES ('$novoAto')";
							$resultInsertAto = @mysqli_query($link, $queryInsertAto) or die(mysqli_error($link));

							if($resultInsertAto){

								echo "<div class='alert alert-success' role='alert'>
						  				Cadastro realizado com sucesso!
									</div>";

							}else{
								echo "<div class='alert alert-danger' role='alert'>
						  				Deu ruim!
									</div>";
							}

						}

						//Verificando se houve o envio
					    if(isset($_GET['id_ato'])){
					    	//Recebe 
						    $id_ato= $_GET['id_ato'];

						    //de verificação de vínculo ato/voluntário
						    $queryVerificarVoluntarioAto = "SELECT atos_id_ato FROM voluntario_atos WHERE atos_id_ato='$id_ato'"; 
							$resultVerificarVoluntarioAto = @mysqli_query($link, $queryVerificarVoluntarioAto);

							//Verificando se o resultado está vazio
							if(!empty($resultVerificarVoluntarioAto)){
								$registroVerificarVoluntarioAto = mysqli_fetch_assoc($resultVerificarVoluntarioAto);

								//Verificando se esse ato está associado a um voluntário
								if($registroVerificarVoluntarioAto['atos_id_ato'] == $id_ato){

									echo "<div class='alert alert-danger' role='alert'>
						  				Esse ato está vinculado a um voluntário e não pode ser deletado.
									</div>";
									
								}else{

									//SQL de exclusão do ato
									$queryDeleteAto = "DELETE FROM atos WHERE id_ato = '$id_ato'"; 
									$resultDeleteAto = @mysqli_query($link, $queryDeleteAto) or die(mysqli_connect_error($link));
									if($resultDeleteAto){
										echo "<div class='alert alert-success' role='alert'>
							  				Deletado com sucesso!
										</div>";
										
									}else{
										echo "<div class='alert alert-danger' role='alert'>
								  				Deu ruim!
											</div>";
									}
									
								}
							}

					    }

					?>

					<table class="table table-bordered">
						<thead>
							<tr>
								<td>#</td>
								<td>Nome</td>
								<td>Deletar</td>
							</tr>
						</thead>
						<tbody>
							<?php

								//SQL de consulta dos atos
								$queryAtos = "SELECT * FROM atos"; 
								$resultAtos = @mysqli_query($link, $queryAtos);
								while ($registroAtos = mysqli_fetch_assoc($resultAtos)) {
								
									//Montando a tabela
									echo '<tr>';
									echo '<td>'.$registroAtos["id_ato"].'</td>';
									echo '<td>'.$registroAtos["nome"].'</td>';
									echo '<td><a href="gerenciarAtoCidade.php?id_ato='.$registroAtos["id_ato"].'"><span style="margin-left:20px;" class="glyphicon glyphicon-trash"></span></a></td>';
									echo '</tr>';
								
								}
						    ?>
						</tbody>
					</table>
				    <br>

					<div>
						<label>Nome do ato:</label>
						<input class="form-control" type="text" name="novoAto" placeholder="Ex: Ajudar idosos"><br>
					</div>
					<button style="margin-top:10px;" type="submit" class="btn botao">Cadastrar Ato</button>
				</form>
			</div>
			<div class="col-sm-6">
				<form action="gerenciarAtoCidade.php" method="post">

					<h2>Cidades</h2><br>

					<table class="table table-bordered">
						<thead>
							<tr>
								<td>Nome</td>
								<td>Quantidade de pessoas</td>
								<td>Deletar</td>
							</tr>
						</thead>
						<tbody>
							<?php

								//Verificando se houve o envio
								if(isset($_POST['novaCidade'])){

									//Recebe 
									$cidade= $_POST['novaCidade'];
									$qnt_pessoas = $_POST['qnt_pessoas'];

									//SQL de inserção da cidade
									$queryInsertRegiao = "INSERT INTO regiao (nome, qnt_pessoas) VALUES ('$cidade', '$qnt_pessoas')";
									$resultInsertRegiao = @mysqli_query($link, $queryInsertRegiao) or die(mysqli_error($link));

									if($resultInsertRegiao){

										echo "<div class='alert alert-success' role='alert'>
								  				Cadastro realizado com sucesso!
											</div>";

									}else{
										echo "<div class='alert alert-danger' role='alert'>
								  				Deu ruim!
											</div>";
									}

								}

								//Verificando se houve o envio
								if(isset($_GET['nome_regiao'])){

									//Recebe 
								    $nome_regiao= $_GET['nome_regiao'];

									//SQL de verificação de vínculo cidade/voluntário
								    $queryVerificarVoluntarioRegiao = "SELECT regiao_nome FROM voluntario_regiao WHERE regiao_nome='$nome_regiao'"; 
									$resultVerificarVoluntarioRegiao = @mysqli_query($link, $queryVerificarVoluntarioRegiao);

									//Verificando se o resultado está vazio
									if(!empty($resultVerificarVoluntarioAto)){

										$registroVerificarVoluntarioRegiao = mysqli_fetch_assoc($resultVerificarVoluntarioRegiao);

										//Verificando se essa cidade está associada a um voluntário
										if($registroVerificarVoluntarioRegiao['regiao_nome'] == $nome_regiao){
											echo "<div class='alert alert-danger' role='alert'>
								  				Essa cidade está vinculada a um voluntário e não pode ser deletada.
											</div>";

										}else{

											//SQL de exclusão da cidade
											$queryDeleteRegiao = "DELETE FROM regiao WHERE nome = '$nome_regiao'"; 
											$resultDeleteRegiao = @mysqli_query($link, $queryDeleteRegiao) or die(mysqli_connect_error($link));
											if($resultDeleteRegiao){
												echo "<div class='alert alert-success' role='alert'>
									  				Deletado com sucesso!
												</div>";
												
											}else{
												echo "<div class='alert alert-danger' role='alert'>
									  				Deu ruim!
												</div>";
											}
										}
									}
								}

								//SQL de consulta das cidades
								$queryRegiao = "SELECT * FROM regiao"; 
								$resultRegiao = @mysqli_query($link, $queryRegiao);
								while ($registroRegiao = mysqli_fetch_assoc($resultRegiao)) {
								
									//Montando a tabela
									echo '<tr>';
									echo '<td>'.$registroRegiao["nome"].'</td>';
									echo '<td>'.$registroRegiao["qnt_pessoas"].'</td>';
									echo '<td><a href="gerenciarAtoCidade.php?nome_regiao='.$registroRegiao["nome"].'"><span style="margin-left:20px;" class="glyphicon glyphicon-trash"></span></a></td>';
									echo '</tr>';
								
								}

							    //Fecha Conexão	
							    DB_Close($link);
						    ?>
						</tbody>
					</table>
				    <br>

				    <div class="row">
				    	<div class="col-sm-7">
							<label>Nome da cidade:</label>
							<input class="form-control" type="text" name="novaCidade" placeholder="Ex: Posse-GO"><br>
						</div>
				    	<div class="col-sm-5">
							<label>Quantidade de pessoas:</label>
							<input class="form-control" type="text" name="qnt_pessoas" placeholder="Ex: 15.123"><br>
						</div>
				    </div>
					<button style="margin-top:10px;" type="submit" class="btn botao">Cadastrar Cidade</button>

				</form>
			</div>
		</div>
	</div>
</body>
</html>