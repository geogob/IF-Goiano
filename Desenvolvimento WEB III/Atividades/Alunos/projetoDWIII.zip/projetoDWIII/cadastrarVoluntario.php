<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios:Cadastro</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/voluntario.css">
</head>
<body>

	<div class="container">
		<div >
			<h1 class="voluntario"><a href="index.php">Voluntários</a></h1>
		</div>
	</div>

	<nav class="menu">
		<div class="container">
			<ul >
				<li class="menu_item"><a href="index.php">Voluntários</a></li>
				<li class="menu_item ativo"><a href="#">Cadastrar voluntário</a></li>
				<li class="menu_item"><a href="gerenciarAtoCidade.php">Gerenciar atos e cidades</a></li>
				<li class="menu_item"><a href="vincularAtoCidade.php">Gerenciar atos e cidades dos voluntários</a></li>
			</ul>	
		</div>
	</nav>
	<div class="container">

		<ol class="breadcrumb">
		  <li><a href="index.php">Home</a></li>
		  <li class="active">Cadastrar Voluntário</li>
		</ol>
		
		<form style="margin-top: 20px;" action="cadastrarVoluntario.php" method="post" id="form">

			<h2>Formulário do voluntário</h2><br>

			<?php

				//realizando a conexão com o banco
				require 'conexaoDB.php';
				$link = DB_connect();

				//Verificando se houve o envio
				if(isset($_POST['nome'])){

					//Verificando os campos
					if($_POST['nome'] != null && $_POST['idade'] != null && $_POST['sexo'] != null){

						//Recebe
						$nome = $_POST['nome'];
						$idade = $_POST['idade'];
						$sexo = $_POST['sexo'];

						//SQL de inserção de voluntários
						$queryInsertVoluntario = "INSERT INTO voluntario (nome, sexo, idade) VALUES ('$nome', '$sexo', '$idade')";
						$resultInsertVoluntario = @mysqli_query($link, $queryInsertVoluntario) or die(mysqli_error($link));

						if($resultInsertVoluntario){

							echo "<div class='alert alert-success' role='alert'>
					  				Cadastro realizado com sucesso!
								</div>";

						}else{
							echo "<div class='alert alert-danger' role='alert'>
					  				Deu ruim!
								</div>";
						}

					}else{
						echo "<div class='alert alert-danger' role='alert'>
						  		 Um ou mais campos não foram preenchidos.
							</div>";
					}
				}
			?>

			<div class="row">

				<div class="col-sm-8">
					<label>Nome:</label>
					<input class="form-control" type="text" name="nome" placeholder="Ex: Fernando Soares"><br>
				</div>
				<div class="col-sm-4">
					<label>Idade:</label>
					<input class="form-control" type="text" name="idade" placeholder="Ex: 18">
				</div>
				
			</div>

			<label style="margin-right:10px;">Sexo:</label>
			<label><input type="radio" name="sexo" value="Masculino" checked> Masculino</label>
			<label style="margin-left:10px"><input type="radio" name="sexo" value="Feminino"> Feminino</label><br>

			<br>
			<button style="margin-top:10px;" type="submit" class="btn botao">Cadastrar</button>

		</form>

	</div>
</body>
</html>