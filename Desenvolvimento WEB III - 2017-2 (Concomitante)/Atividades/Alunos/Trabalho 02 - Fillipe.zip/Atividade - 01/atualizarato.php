<?php
	//Realizando a conexão com o banco
	require 'config.php';
	require 'conexao.php';
	$link = DB_connect();

	//Recebe
	$id = $_GET['id'];

	//Recebe
	$ato = $_POST['ato'];

	$query = "UPDATE ato SET acao = '$ato' WHERE idAto = $id";

	$result = @mysqli_query($link, $query);

	if($result){
		echo "Atualizado
		 com sucesso!";
		?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="consultarato.php" method="post">
				<button id="Submit">Voltar a Consulta</button>
			</form>
		<?php
	}else{
		echo "Deu ruim";
	}

	//Fecha conexão
	DB_Close($link);

?>