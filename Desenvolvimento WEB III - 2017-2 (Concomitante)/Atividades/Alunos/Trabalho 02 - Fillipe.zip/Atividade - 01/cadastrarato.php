<?php

	//Realizando a conexão com o banco
	require 'config.php';
	require 'conexao.php';
	$link = DB_connect();

	//Recebe
	$ato = $_POST['ato'];

	//Consulta SQL de inserção
	$query = "INSERT INTO ato (acao) VALUES ('$ato')";

	$result = @mysqli_query($link, $query) or die(mysqli_error($link));

	if($result){
		echo "Cadastrado com sucesso!";
		?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="ato.php" method="post">
				<button id="Submit">Voltar ao Cadastro</button>
			</form>
		<?php
	}else{
		echo "Deu ruim";
	}

	//Fecha conexão
	DB_Close($link);
?>