<?php 
	    //Realizando a conexão com o banco
	    require 'config.php'; 
	    require 'conexao.php';
	    $link = DB_connect();

		//Consulta SQL de inserção:
		$query = "SELECT * FROM ato"; 
		$result = @mysqli_query($link, $query);

		echo '<table>';
		echo '<tr>';
		echo '<td> <h2> Ação </h2> </td>';
		echo '</tr>';
		while ($registro = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo '<td> <i>'.$registro["acao"].'</i></td>';
			$id = $registro["idAto"];
			echo '<td> <a href="deletarato.php?id='.$id.'">Deletar</a> </td>';
			echo '<td> <a href="formatualizarato.php?id='.$id.'">Atualizar</a> </td>';
			echo '</tr>';
		}
		echo '</table>';
		echo '</table>';
		echo '<form action="Menu.php" method="post">';
		echo '<button id="Submit">Voltar ao Menu</button>';
		echo '</form>';
		echo '<form action="ato.php" method="post">';
		echo '<button id="Submit">Voltar ao Cadastro</button>';
		echo '</form>';
	    //Fecha Conexão	
	    DB_Close($link);
?>