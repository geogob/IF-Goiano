<?php
	//Realizando a conexão com o banco
	require 'config.php';
	require 'conexao.php';
	$link = DB_connect();

	//Recebe
	$id = $_GET['id'];

	//Recebe
	$qtdpessoas = $_POST['qtdPessoas'];
	$endereco = $_POST['endereco'];

	$query = "UPDATE regiao SET qntPessoas = '$qtdpessoas', endereco = '$endereco' WHERE idRegiao = $id";

	$result = @mysqli_query($link, $query);

	if($result){
		echo "Atualizado
		 com sucesso!";
		?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="consultarregiao.php" method="post">
				<button id="Submit">Voltar a Consulta</button>
			</form>
		<?php
	}else{
		echo "Deu ruim";
	}

	//Fecha conexão
	DB_Close($link);

?>