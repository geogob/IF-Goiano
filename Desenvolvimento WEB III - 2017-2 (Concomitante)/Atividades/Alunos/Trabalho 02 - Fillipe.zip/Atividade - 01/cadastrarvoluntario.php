<?php

	//Realizando a conexão com o banco
	require 'config.php';
	require 'conexao.php';
	$link = DB_connect();

	//Recebe
	$nome = $_POST['nome'];
	$idade = $_POST['idade'];
	$sexo = $_POST['sexo'];

	//Consulta SQL de inserção
	$query = "INSERT INTO voluntarios (nome, sexo, idade) VALUES ('$nome', '$sexo', '$idade')";

	$result = @mysqli_query($link, $query) or die(mysqli_error($link));

	if($result){
		echo "Cadastrado com sucesso!";
		?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="voluntario.php" method="post">
				<button id="Submit">Voltar ao Cadastro</button>
			</form>
		<?php
	}else{
		echo "Deu ruim";
	}

	//Fecha conexão
	DB_Close($link);
?>