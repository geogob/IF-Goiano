<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="Redirecionador.php?value=1">VOLUNTÁRIOS</a></br>
	<a href="Redirecionador.php?value=2">ATOS</a></br>
	<a href="Redirecionador.php?value=3">REGIÕES</a>
</body>
</html>