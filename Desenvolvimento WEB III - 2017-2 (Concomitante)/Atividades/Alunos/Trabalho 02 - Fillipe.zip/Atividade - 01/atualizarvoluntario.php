<?php
	//Realizando a conexão com o banco
	require 'config.php';
	require 'conexao.php';
	$link = DB_connect();

	//Recebe
	$id = $_GET['id'];

	//Recebe
	$nome = $_POST['nome'];
	$idade = $_POST['idade'];
	$sexo = $_POST['sexo'];

	$query = "UPDATE voluntarios SET nome = '$nome', idade = '$idade', sexo = '$sexo' WHERE idVoluntarios = $id";

	$result = @mysqli_query($link, $query);

	if($result){
		echo "Atualizado
		 com sucesso!";
		?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="consultarvoluntario.php" method="post">
				<button id="Submit">Voltar a Consulta</button>
			</form>
		<?php
	}else{
		echo "Deu ruim";
	}

	//Fecha conexão
	DB_Close($link);

?>