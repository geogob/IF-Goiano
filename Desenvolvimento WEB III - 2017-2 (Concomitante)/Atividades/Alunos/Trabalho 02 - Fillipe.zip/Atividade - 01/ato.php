<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>
		Informe os dados do Ato
	</h2>
	<form action="cadastrarato.php" method="post">
		Ato:
		<input name="ato" id="campo-ato" type="text">
		<button id="Submit">Cadastrar</button>
	</form>
	</br>
	<form action="consultarato.php" method="post">
		<button id="Submit">Consultar</button>
	</form>
	</br>
	<form action="Menu.php" method="post">
		<button id="Submit">Voltar ao Menu</button>
	</form>
</body>
</html>