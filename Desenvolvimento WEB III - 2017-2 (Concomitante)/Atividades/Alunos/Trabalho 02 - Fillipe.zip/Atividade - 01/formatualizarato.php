<?php
	
	$id = $_GET['id'];

	echo '<form action="atualizarato.php?id=' . $id . '"method="post">';
	?>

		<h2>
			Informe os dados do Ato
		</h2>
		<form action="cadastrarato.php" method="post">
			Ato:
			<input name="ato" id="campo-ato" type="text">
			<button id="Submit">Cadastrar</button>
		</form>
		</br>
		<form action="consultarato.php" method="post">
			<button id="Submit">Cancelar</button>
		</form>