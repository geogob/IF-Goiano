<?php 
	    //Realizando a conexão com o banco
	    require 'config.php'; 
	    require 'conexao.php';
	    $link = DB_connect();

		//Consulta SQL de inserção:
		$query = "SELECT * FROM voluntarios"; 
		$result = @mysqli_query($link, $query);

		echo '<table>';
		echo '<tr>';
		echo '<td> <h2> Nome </h2> </td>';
		echo '<td> <h2> Idade </h2></td>';
		echo '<td> <h2> Sexo </h2></td>';
		echo '</tr>';
		while ($registro = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo '<td> <i>'.$registro["nome"].'</i></td>';
			echo '<td> <b>'.$registro["idade"].'</b> </td>';
			echo '<td> <i>'.$registro["sexo"].'</i></td>';
			$id = $registro["idVoluntarios"];
			echo '<td> <a href="deletarvoluntario.php?id='.$id.'">Deletar</a> </td>';
			echo '<td> <a href="formatualizarvoluntario.php?id='.$id.'">Atualizar</a> </td>';
			echo '<td> <a href="#">Adicionar Ato</a> </td>';
			echo '<td> <a href="#">Adicionar Regiao</a> </td>';
			echo '</tr>';
		}
		echo '</table>';
		echo '</table>';
		echo '<form action="Menu.php" method="post">';
		echo '<button id="Submit">Voltar ao Menu</button>';
		echo '</form>';
		echo '<form action="voluntario.php" method="post">';
		echo '<button id="Submit">Voltar ao Cadastro</button>';
		echo '</form>';
	    //Fecha Conexão	
	    DB_Close($link);
?>