<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>
		Informe os dados da Região
	</h2>
	<form action="cadastrarregiao.php" method="post">
		Quantidade de Pessoas:
		<input name="qtdPessoas" id="campo-qtd" type="text" placeholder="Ex: 10"></br>

		Endereço:
		<input name="endereco" id="campo-endereco" type="text"></br>
		<button id="Submit">Cadastrar</button>
	</form>
	<form action="consultarregiao.php" method="post">
		<button id="Submit">Consultar</button>
	</form>
	<form action="Menu.php" method="post">
		<button id="Submit">Voltar ao Menu</button>
	</form>
</body>
</html>