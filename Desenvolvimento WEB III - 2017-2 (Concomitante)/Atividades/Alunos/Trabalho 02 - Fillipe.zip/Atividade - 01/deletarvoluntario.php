<?php 
	    //Realizando a conexão com o banco
	    require 'config.php'; 
	    require 'conexao.php';
	    $link = DB_connect();

	    //Recebe 
	    $id= $_GET['id'];

		//Consulta SQL de inserção:
		$query = "DELETE FROM voluntarios WHERE idVoluntarios = '$id'"; 
		$result = @mysqli_query($link, $query) or die(mysqli_connect_error($link));

		if($result){
			echo "Removido com sucesso";
			?>
			<form action="Menu.php" method="post">
				<button id="Submit">Voltar ao Menu</button>
			</form>
			<form action="consultarvoluntario.php" method="post">
				<button id="Submit">Voltar a Consulta</button>
			</form>
			<?php
		}else{
			echo "Deu ruim";
		}
	    //Fecha Conexão	
	    DB_Close($link);
?>