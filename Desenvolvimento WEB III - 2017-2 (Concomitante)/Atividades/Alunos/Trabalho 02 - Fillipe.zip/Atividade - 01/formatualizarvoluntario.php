<?php
	
	$id = $_GET['id'];

	echo '<form action="atualizarvoluntario.php?id=' . $id . '"method="post">';
	?>

		<h2>
			Informe os dados do Voluntário
		</h2>
		<form action="cadastrarvoluntario.php" method="post">
			Nome:
			<input name="nome" id="campo-nome" type="text" placeholder="Ex: Fillipe Soares"></br>

			Sexo:
			<input name="sexo" id="campo-sexo" type="text" placeholder="Ex: Masculino"></br>

			Idade:
			<input name="idade" id="campo-idade" type="text" placeholder="Ex: 25"></br>
			<button id="Submit">Cadastrar</button>
		</form>
		<form action="consultarvoluntario.php" method="post">
			<button id="Submit">Cancelar</button>
		</form>