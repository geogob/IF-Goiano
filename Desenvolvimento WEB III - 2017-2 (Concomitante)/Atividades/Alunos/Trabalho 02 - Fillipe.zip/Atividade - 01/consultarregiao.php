<?php 
	    //Realizando a conexão com o banco
	    require 'config.php'; 
	    require 'conexao.php';
	    $link = DB_connect();

		//Consulta SQL de inserção:
		$query = "SELECT * FROM regiao"; 
		$result = @mysqli_query($link, $query);

		echo '<table>';
		echo '<tr>';
		echo '<td> <h2> Qtd. de Pessoas </h2> </td>';
		echo '<td> <h2> Endereço </h2></td>';
		echo '</tr>';
		while ($registro = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo '<td> <i>'.$registro["qntPessoas"].'</i></td>';
			echo '<td> <b>'.$registro["endereco"].'</b> </td>';
			$id = $registro["idRegiao"];
			echo '<td> <a href="deletarregiao.php?id='.$id.'">Deletar</a> </td>';
			echo '<td> <a href="formatualizarregiao.php?id='.$id.'">Atualizar</a> </td>';
			echo '</tr>';
		}
		echo '</table>';
		echo '<form action="Menu.php" method="post">';
		echo '<button id="Submit">Voltar ao Menu</button>';
		echo '</form>';
		echo '<form action="regiao.php" method="post">';
		echo '<button id="Submit">Voltar ao Cadastro</button>';
		echo '</form>';
	    //Fecha Conexão	
	    DB_Close($link);
?>