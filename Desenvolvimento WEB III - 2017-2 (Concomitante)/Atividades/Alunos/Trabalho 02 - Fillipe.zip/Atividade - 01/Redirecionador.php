<?php
	switch ($_GET['value']){
		case 1:
			include 'voluntario.php';
			break;
		case 2:
			include "ato.php";
			break;
		case 3:
			include "regiao.php";
			break;	
		default:
			echo "OPÇÃO INVÁLIDA!";
			break;
	}
?>