<?php

http://localhost/phpmyadmin/
	define('DB_HOSTNAME', 'localhost'); //Nome do HOST
	define('DB_USERNAME', 'root'); //Usário
	define('DB_PASSWORD', null); //Senha
	define('DB_DATABASE', 'atividade'); //Nome do BD
	//define('DB_PREFIX', 'dw3');
	define('DB_CHARSET', 'utf8');
?>