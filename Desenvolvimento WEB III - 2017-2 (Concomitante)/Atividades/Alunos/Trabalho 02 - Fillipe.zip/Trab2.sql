-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: atividade
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ato`
--

DROP TABLE IF EXISTS `ato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ato` (
  `idAto` int(11) NOT NULL AUTO_INCREMENT,
  `acao` varchar(45) NOT NULL,
  PRIMARY KEY (`idAto`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ato`
--

LOCK TABLES `ato` WRITE;
/*!40000 ALTER TABLE `ato` DISABLE KEYS */;
/*!40000 ALTER TABLE `ato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiao`
--

DROP TABLE IF EXISTS `regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiao` (
  `idRegiao` int(11) NOT NULL AUTO_INCREMENT,
  `qntPessoas` varchar(45) NOT NULL,
  `endereco` varchar(45) NOT NULL,
  PRIMARY KEY (`idRegiao`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiao`
--

LOCK TABLES `regiao` WRITE;
/*!40000 ALTER TABLE `regiao` DISABLE KEYS */;
/*!40000 ALTER TABLE `regiao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios`
--

DROP TABLE IF EXISTS `voluntarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios` (
  `idVoluntarios` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `idade` int(11) NOT NULL,
  PRIMARY KEY (`idVoluntarios`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios`
--

LOCK TABLES `voluntarios` WRITE;
/*!40000 ALTER TABLE `voluntarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `voluntarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios_has_ato`
--

DROP TABLE IF EXISTS `voluntarios_has_ato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios_has_ato` (
  `voluntarios_idVoluntarios` int(11) NOT NULL,
  `ato_idAto` int(11) NOT NULL,
  PRIMARY KEY (`voluntarios_idVoluntarios`,`ato_idAto`),
  KEY `fk_voluntarios_has_ato_ato1_idx` (`ato_idAto`),
  KEY `fk_voluntarios_has_ato_voluntarios_idx` (`voluntarios_idVoluntarios`),
  CONSTRAINT `fk_voluntarios_has_ato_ato1` FOREIGN KEY (`ato_idAto`) REFERENCES `ato` (`idAto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_voluntarios_has_ato_voluntarios` FOREIGN KEY (`voluntarios_idVoluntarios`) REFERENCES `voluntarios` (`idVoluntarios`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios_has_ato`
--

LOCK TABLES `voluntarios_has_ato` WRITE;
/*!40000 ALTER TABLE `voluntarios_has_ato` DISABLE KEYS */;
/*!40000 ALTER TABLE `voluntarios_has_ato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voluntarios_has_regiao`
--

DROP TABLE IF EXISTS `voluntarios_has_regiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voluntarios_has_regiao` (
  `voluntarios_idVoluntarios` int(11) NOT NULL,
  `regiao_idRegiao` int(11) NOT NULL,
  PRIMARY KEY (`voluntarios_idVoluntarios`,`regiao_idRegiao`),
  KEY `fk_voluntarios_has_regiao_regiao1_idx` (`regiao_idRegiao`),
  KEY `fk_voluntarios_has_regiao_voluntarios1_idx` (`voluntarios_idVoluntarios`),
  CONSTRAINT `fk_voluntarios_has_regiao_regiao1` FOREIGN KEY (`regiao_idRegiao`) REFERENCES `regiao` (`idRegiao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_voluntarios_has_regiao_voluntarios1` FOREIGN KEY (`voluntarios_idVoluntarios`) REFERENCES `voluntarios` (`idVoluntarios`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voluntarios_has_regiao`
--

LOCK TABLES `voluntarios_has_regiao` WRITE;
/*!40000 ALTER TABLE `voluntarios_has_regiao` DISABLE KEYS */;
/*!40000 ALTER TABLE `voluntarios_has_regiao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-25 20:56:19
